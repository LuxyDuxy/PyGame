import time
import pygame
import random
import keyboard
from pygame import event
pygame.init()
pygame.font.init()
myfont = pygame.font.SysFont('Comic Sans MS', 30)
screen = pygame.display.set_mode((1007, 700))
pygame.display.set_caption('Space Invaders')
icon = pygame.image.load('Spaceship.png')
pygame.display.set_icon(icon)
player = pygame.image.load('Player.png')
playerX = 250
playerY = 360
enemy = pygame.image.load('Enemy.png')
enemy1 = pygame.image.load('Enemy.png')
enemyY = -300
enemyY1 = -300
bullet = []
bullet = pygame.image.load('Bullet.png')
bulletY = 300
bullet_fired = 0
bulletX_when_fired = 99999999
bulletY_fixed = 0
position_fix = 0
remove_bullet = 0
score = 0
no_collision = 0
death_screen = False
def Player(x, y):
    screen.blit(player, (x, y))
def RandomEnemyX():
    random_enemyX = random.randrange(-200, 700)
    return(random_enemyX)
def RandomEnemyX1():
    random_enemyX1 = random.randrange(-200, 700)
    return(random_enemyX1)    
RandomEnemyX()
RandomEnemyX1()
enemyX = RandomEnemyX() 
enemyX1 = RandomEnemyX1()        
def Enemy(x, y, z, b):
    global no_collision
    global enemyX
    global enemyY 
    if abs(enemyX - z) < 30 and abs(enemyY - b) < 30 and no_collision == 0:
        global bulletX_when_fired
        bulletX_when_fired = 99999999 
        no_collision = 1
        global score
        score += 1
        enemyY = -300
        enemyX = RandomEnemyX()
        global remove_bullet
        remove_bullet = 1
    else:
        screen.blit(enemy, (x, y))  
    enemyY += 5
    random_number = random.randint(1, 2) 
    if random_number == 1:
        if enemyX >= -170:
            enemyX += -10
        else:
            enemyX += 10 
    if random_number == 2:
        if enemyX <= 670:
            enemyX += 10
        else:
            enemyX += -10 
def Enemy1(x, y, z, b):
    global no_collision
    global enemyX1
    global enemyY1
    if abs(enemyX1 - z) < 30 and abs(enemyY1 - b) < 30 and no_collision == 0:
        global bulletX_when_fired
        bulletX_when_fired = 99999999 
        no_collision = 1
        global score
        score += 1
        enemyY1 = -300
        enemyX1 = RandomEnemyX1()
        global remove_bullet
        remove_bullet = 1    
    else:
        screen.blit(enemy1, (x, y))  
    enemyY1 += 5
    random_number = random.randint(1, 2) 
    if random_number == 1:
        if enemyX1 >= -170:
            enemyX1 += -10
        else:
            enemyX1 += 10 
    if random_number == 2:
        if enemyX1 <= 670:
            enemyX1 += 10
        else:
            enemyX1 += -10                                       
def GameOver():
    global enemyY
    global enemyY1
    global enemyX
    global enemyX1
    enemyX = RandomEnemyX()
    enemyX1 = RandomEnemyX1()
    enemyY = -300
    enemyY1 = -300
    screen.fill((255, 0, 0))
    global running 
    running = False 
    global death_screen
    death_screen = True 
    while death_screen:
        time.sleep(0.03)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  
                death_screen = False 
            button1.click(event)
        button1.show()
        clock.tick(30)    
        pygame.display.update()  
def BulletPositionFix(x, y, z):
    if x == 1:
        y = z - 60
        return(y)
    else:
        return(y)
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 20)
class Button:
    def __init__(self, text,  pos, font, bg="black"):
        self.x, self.y = pos
        self.font = pygame.font.SysFont("Arial", font)
        self.change_text(text, bg)
    def change_text(self, text, bg="black"):
        self.text = self.font.render(text, 1, pygame.Color("White"))
        self.size = self.text.get_size()
        self.surface = pygame.Surface(self.size)
        self.surface.fill(bg)
        self.surface.blit(self.text, (0, 0))
        self.rect = pygame.Rect(self.x, self.y, self.size[0], self.size[1])
    def show(self):
        screen.blit(button1.surface, (self.x, self.y))
    def click(self, event):
        x, y = pygame.mouse.get_pos()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if pygame.mouse.get_pressed()[0]:
                if self.rect.collidepoint(x, y):
                    global running
                    global death_screen
                    global score 
                    score = 0
                    global playerX
                    playerX = 250
                    death_screen = False
                    running = True
button1 = Button("Restart", (385, 425), font = 64, bg = "red")       
running = True
while running:
    time.sleep(0.03)
    if playerX >= -170:
        if keyboard.is_pressed('left'):
            playerX -= 10
    if playerX <= 670:    
        if keyboard.is_pressed('right'):
            playerX += 10      
    screen.fill((1, 0, 5))
    Player(playerX, playerY)  
    if abs(enemyY - playerY) < 50 and abs(enemyX - playerX) < 40:
        GameOver()  
    if abs(enemyY1 - playerY) < 50 and abs(enemyX1 - playerX) < 40:
        GameOver()      
    if enemyY > 600:
        enemyY = -300
        enemyX = RandomEnemyX()
    if enemyY1 > 600:
        enemyY1 = -300
        enemyX1 = RandomEnemyX1()
    bulletX = playerX - 5       
    if keyboard.is_pressed('space') and bullet_fired == 0:
        bulletX_when_fired = bulletX
        bullet_fired = 1
        position_fix = 1
        bulletY_fixed = BulletPositionFix(position_fix, bulletY, playerY)
    if bullet_fired == 1:
        position_fix = 0
        if bulletY_fixed != -300:
            if remove_bullet == 0:
                screen.blit(bullet, (bulletX_when_fired, bulletY_fixed))
                bulletY_fixed += -30   
            else:
                screen.blit(bullet, (bulletX_when_fired, bulletY_fixed))
                bulletY_fixed += -30
                screen.fill((1, 0, 5))
        else:
            bullet_fired = 0
            remove_bullet = 0
            bulletY = playerY
    if bulletY_fixed == -300:
        bulletX_when_fired = 99999999
        no_collision = 0        
    Player(playerX, playerY)        
    Enemy(enemyX, enemyY, bulletX_when_fired, bulletY_fixed) 
    Enemy1(enemyX1, enemyY1, bulletX_when_fired, bulletY_fixed)
    if abs(enemyY - enemyY1) < 150: 
        if enemyY < enemyY1:
            enemyY += -150
        if enemyY1 < enemyY:
            enemyY1 += -150
        else:
            enemyY += -200    
    textsurface = myfont.render('Score: {0}'.format(score), True, (0, 255, 0)) 
    screen.blit(textsurface,(20, 20)) 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False  
    pygame.display.update()        